#!/usr/bin/env python3
"""局域网/公网临时分享网关：访问编辑器前必须提交申请并由管理员批准。"""
from __future__ import annotations

import argparse
import html
import json
import mimetypes
import os
import posixpath
import secrets
import sys
import time
from http import HTTPStatus
from http.cookies import SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, quote, urlencode, urlparse

STATE_FILE = "public-share-approvals.json"
COOKIE_NAME = "yishi_share_token"
SESSION_HOURS = 12
MAX_BODY = 64 * 1024


def now() -> int:
    return int(time.time())


def esc(value: object) -> str:
    return html.escape(str(value or ""), quote=True)


def json_bytes(value: object) -> bytes:
    return json.dumps(value, ensure_ascii=False, indent=2).encode("utf-8")


class ShareState:
    def __init__(self, path: Path):
        self.path = path
        self.requests: dict[str, dict] = {}
        self.load()

    def load(self):
        try:
            data = json.loads(self.path.read_text(encoding="utf-8"))
            self.requests = data if isinstance(data, dict) else {}
        except (FileNotFoundError, json.JSONDecodeError, OSError):
            self.requests = {}
        self.cleanup()

    def save(self):
        temp = self.path.with_suffix(self.path.suffix + ".tmp")
        temp.write_text(json.dumps(self.requests, ensure_ascii=False, indent=2), encoding="utf-8")
        temp.replace(self.path)

    def cleanup(self):
        cutoff = now() - SESSION_HOURS * 3600
        self.requests = {k: v for k, v in self.requests.items() if int(v.get("created", 0)) >= cutoff}

    def get(self, token: str) -> dict | None:
        self.cleanup()
        return self.requests.get(token)


REQUEST_PAGE = """<!doctype html>
<html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>等待访问批准</title>
<style>body{margin:0;background:#10131a;color:#e9edf5;font:15px system-ui,"Microsoft YaHei",sans-serif;display:grid;place-items:center;min-height:100vh}.card{width:min(460px,calc(100vw - 36px));background:#1b202a;border:1px solid #394353;border-radius:12px;padding:24px;box-shadow:0 16px 60px #0008}h1{font-size:22px;margin:0 0 8px}.muted{color:#9aa4b4;font-size:13px;line-height:1.7}.field{margin-top:14px}label{display:block;color:#b9c1cf;margin-bottom:6px}input,textarea{width:100%;box-sizing:border-box;background:#11151c;color:#fff;border:1px solid #3a4452;border-radius:6px;padding:10px;outline:0}textarea{height:90px;resize:vertical}button{margin-top:16px;width:100%;height:40px;border:0;border-radius:6px;background:#e35d45;color:white;font-weight:700;cursor:pointer}button:disabled{opacity:.6}.status{margin-top:16px;padding:10px;border-radius:6px;background:#252c38;color:#b8c2d2}.ok{color:#61d49b}.warn{color:#f5b55b}</style></head>
<body><main class=\"card\"><h1>访问申请</h1><p class=\"muted\">此编辑器需要管理员批准后才能打开。提交申请后请等待管理员处理。</p>
<form id=\"form\"><div class=\"field\"><label>称呼</label><input name=\"name\" maxlength=\"40\" required placeholder=\"例如：张三\"></div><div class=\"field\"><label>申请说明</label><textarea name=\"message\" maxlength=\"300\" placeholder=\"说明你需要编辑什么内容\"></textarea></div><button id=\"submit\">提交申请</button></form><div class=\"status\" id=\"status\">尚未提交申请</div></main>
<script>const form=document.querySelector('#form'),statusBox=document.querySelector('#status'),submit=document.querySelector('#submit');async function status(){const r=await fetch('/api/status',{cache:'no-store'});const d=await r.json();if(d.status==='approved'){statusBox.innerHTML='<span class=\"ok\">申请已批准，正在打开编辑器…</span>';location.href=d.redirect;return}if(d.status==='rejected'){statusBox.innerHTML='<span class=\"warn\">申请被拒绝。</span>';submit.disabled=false;return}if(d.status==='pending'){statusBox.textContent='申请已提交，等待管理员批准…';submit.disabled=true}}form.addEventListener('submit',async e=>{e.preventDefault();submit.disabled=true;const r=await fetch('/api/request',{method:'POST',headers:{'Content-Type':'application/x-www-form-urlencoded'},body:new URLSearchParams(new FormData(form))});const d=await r.json();statusBox.textContent=d.message||'申请已提交';if(d.ok)setInterval(status,2500);else submit.disabled=false});</script></body></html>"""


ADMIN_PAGE = """<!doctype html><html lang=\"zh-CN\"><head><meta charset=\"utf-8\"><meta name=\"viewport\" content=\"width=device-width,initial-scale=1\"><title>访问审批</title><style>body{margin:0;background:#10131a;color:#e9edf5;font:14px system-ui,"Microsoft YaHei",sans-serif;padding:24px}.head{display:flex;justify-content:space-between;align-items:center;gap:12px}h1{font-size:22px}.muted{color:#9aa4b4}.list{display:grid;gap:10px;margin-top:18px}.item{background:#1b202a;border:1px solid #394353;border-radius:9px;padding:14px;display:grid;grid-template-columns:1fr auto;gap:12px}.meta{line-height:1.7}.actions{display:flex;align-items:center;gap:7px}button{border:0;border-radius:5px;padding:8px 12px;color:#fff;cursor:pointer;font-weight:700}.approve{background:#299c6a}.reject{background:#a9434e}.empty{padding:30px;color:#9aa4b4;background:#1b202a;border-radius:9px}</style></head><body><div class=\"head\"><div><h1>编辑器访问审批</h1><div class=\"muted\">只在本机管理员页面批准申请</div></div><button onclick=\"load()\">刷新</button></div><div class=\"list\" id=\"list\"></div><script>const key=new URLSearchParams(location.search).get('key');async function decide(token,decision){await fetch('/api/admin/decision?'+new URLSearchParams({key,token,decision}),{method:'POST'});load()}async function load(){const r=await fetch('/api/admin/list?key='+encodeURIComponent(key),{cache:'no-store'});if(!r.ok){document.querySelector('#list').innerHTML='<div class=\"empty\">管理员密钥无效</div>';return}const rows=await r.json();document.querySelector('#list').innerHTML=rows.length?rows.map(x=>'<article class=\"item\"><div class=\"meta\"><b>'+x.name+'</b><br>'+x.message+'<br><span class=\"muted\">申请时间：'+new Date(x.created*1000).toLocaleString()+' · '+x.status+'</span></div><div class=\"actions\"><button class=\"approve\" onclick=\"decide(\\''+x.token+'\\',\\'approve\\')\">批准</button><button class=\"reject\" onclick=\"decide(\\''+x.token+'\\',\\'reject\\')\">拒绝</button></div></article>').join(''):'<div class=\"empty\">暂无申请</div>'}load();setInterval(load,5000)</script></body></html>"""


class Handler(BaseHTTPRequestHandler):
    server_version = "YishiShare/1.0"

    @property
    def app(self):
        return self.server.app  # type: ignore[attr-defined]

    def log_message(self, fmt, *args):
        sys.stderr.write("[share] " + (fmt % args) + "\n")

    def send_bytes(self, body: bytes, content_type: str = "text/html; charset=utf-8", status=HTTPStatus.OK, cookies=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        if cookies:
            for cookie in cookies:
                self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def redirect(self, location: str, cookies=None):
        self.send_response(HTTPStatus.SEE_OTHER)
        self.send_header("Location", location)
        if cookies:
            for cookie in cookies:
                self.send_header("Set-Cookie", cookie)
        self.end_headers()

    def cookies(self):
        jar = SimpleCookie()
        jar.load(self.headers.get("Cookie", ""))
        return {k: v.value for k, v in jar.items()}

    def ensure_token(self):
        token = self.cookies().get(COOKIE_NAME)
        if token and self.app.state.get(token):
            return token, []
        token = secrets.token_urlsafe(32)
        self.app.state.requests[token] = {"token": token, "status": "new", "name": "", "message": "", "created": now(), "path": "/tools/scene-ui-editor.html", "ip": self.client_address[0]}
        self.app.state.save()
        return token, [f"{COOKIE_NAME}={token}; Path=/; HttpOnly; SameSite=Lax; Max-Age={SESSION_HOURS * 3600}"]

    def approved(self):
        token = self.cookies().get(COOKIE_NAME)
        record = self.app.state.get(token or "")
        return record if record and record.get("status") == "approved" else None

    def do_GET(self):
        parsed = urlparse(self.path)
        if parsed.path == "/admin":
            key = parse_qs(parsed.query).get("key", [""])[0]
            if key != self.app.admin_key:
                self.send_bytes(b"invalid admin key", "text/plain; charset=utf-8", HTTPStatus.FORBIDDEN)
            else:
                self.send_bytes(ADMIN_PAGE.encode("utf-8"))
            return
        if parsed.path == "/api/status":
            record = self.app.state.get(self.cookies().get(COOKIE_NAME, ""))
            if not record:
                self.send_bytes(json_bytes({"status": "new"}), "application/json; charset=utf-8")
            elif record.get("status") == "approved":
                self.send_bytes(json_bytes({"status": "approved", "redirect": record.get("path", "/tools/scene-ui-editor.html")} ), "application/json; charset=utf-8")
            else:
                self.send_bytes(json_bytes({"status": record.get("status", "new")}), "application/json; charset=utf-8")
            return
        if parsed.path == "/api/admin/list":
            if parse_qs(parsed.query).get("key", [""])[0] != self.app.admin_key:
                self.send_bytes(b"invalid admin key", "text/plain; charset=utf-8", HTTPStatus.FORBIDDEN)
                return
            rows = sorted(self.app.state.requests.values(), key=lambda x: x.get("created", 0), reverse=True)
            self.send_bytes(json_bytes(rows), "application/json; charset=utf-8")
            return
        if parsed.path == "/" or parsed.path == "/gate":
            self.redirect("/tools/scene-ui-editor.html")
            return
        record = self.approved()
        if not record:
            token, cookies = self.ensure_token()
            record = self.app.state.get(token)
            record["path"] = parsed.path
            self.app.state.save()
            self.send_bytes(REQUEST_PAGE.encode("utf-8"), cookies=cookies)
            return
        self.serve_public(parsed.path)

    def do_POST(self):
        parsed = urlparse(self.path)
        length = int(self.headers.get("Content-Length", "0"))
        if length > MAX_BODY:
            self.send_bytes(b"request too large", "text/plain", HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
            return
        body = self.rfile.read(length).decode("utf-8", "replace")
        if parsed.path == "/api/request":
            token = self.cookies().get(COOKIE_NAME)
            record = self.app.state.get(token or "")
            if not record:
                self.send_bytes(json_bytes({"ok": False, "message": "申请会话已失效，请刷新页面。"}), "application/json; charset=utf-8", HTTPStatus.BAD_REQUEST)
                return
            form = parse_qs(body)
            record.update({"name": form.get("name", [""])[0][:40], "message": form.get("message", [""])[0][:300], "status": "pending", "created": now(), "ip": self.client_address[0]})
            self.app.state.save()
            self.send_bytes(json_bytes({"ok": True, "message": "申请已提交，请等待管理员批准。"}), "application/json; charset=utf-8")
            return
        if parsed.path == "/api/admin/decision":
            query = parse_qs(parsed.query)
            if query.get("key", [""])[0] != self.app.admin_key:
                self.send_bytes(b"invalid admin key", "text/plain; charset=utf-8", HTTPStatus.FORBIDDEN)
                return
            token, decision = query.get("token", [""])[0], query.get("decision", [""])[0]
            record = self.app.state.get(token)
            if record and decision in ("approve", "reject"):
                record["status"] = "approved" if decision == "approve" else "rejected"
                record["decided"] = now()
                self.app.state.save()
            self.send_bytes(json_bytes({"ok": True}), "application/json; charset=utf-8")
            return
        self.send_bytes(b"not found", "text/plain", HTTPStatus.NOT_FOUND)

    def serve_public(self, path: str):
        clean = posixpath.normpath("/" + path.lstrip("/"))
        if clean.startswith("/tools/"):
            relative = clean.lstrip("/")
        elif clean.startswith("/assets/"):
            relative = clean.lstrip("/")
        else:
            self.send_bytes(b"not found", "text/plain", HTTPStatus.NOT_FOUND)
            return
        target = (self.app.root / relative).resolve()
        try:
            target.relative_to(self.app.root.resolve())
        except ValueError:
            self.send_bytes(b"forbidden", "text/plain", HTTPStatus.FORBIDDEN)
            return
        if not target.is_file():
            self.send_bytes(b"not found", "text/plain", HTTPStatus.NOT_FOUND)
            return
        content_type = mimetypes.guess_type(target.name)[0] or "application/octet-stream"
        self.send_bytes(target.read_bytes(), content_type)


class AppServer(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address, root: Path, admin_key: str, state: ShareState):
        super().__init__(address, Handler)
        self.root = root.resolve()
        self.admin_key = admin_key
        self.state = state
        self.app = self


def main():
    parser = argparse.ArgumentParser(description="带人工审批门禁的异视编辑器分享服务器")
    parser.add_argument("--root", default=".", help="项目根目录")
    parser.add_argument("--bind", default="0.0.0.0", help="监听地址，公网分享使用 0.0.0.0")
    parser.add_argument("--port", type=int, default=8787)
    parser.add_argument("--admin-key", default=os.environ.get("YISHI_ADMIN_KEY", ""), help="管理员密钥；不传则随机生成")
    args = parser.parse_args()
    root = Path(args.root).resolve()
    if not root.is_dir():
        raise SystemExit(f"root 不存在：{root}")
    admin_key = args.admin_key or secrets.token_urlsafe(18)
    state = ShareState(root / STATE_FILE)
    server = AppServer((args.bind, args.port), root, admin_key, state)
    print(f"公网分享服务已启动：http://<公网地址>:{args.port}/tools/scene-ui-editor.html")
    print(f"管理员审批页：http://127.0.0.1:{args.port}/admin?key={quote(admin_key)}")
    print(f"管理员密钥：{admin_key}")
    print("注意：公网使用时请放在 HTTPS 反向代理或安全隧道后面，不要直接裸奔 HTTP。")
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        print("\n服务已停止")
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
