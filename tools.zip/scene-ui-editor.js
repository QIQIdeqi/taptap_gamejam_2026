(() => {
  'use strict';

  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const uid = (prefix = 'node') => `${prefix}_${Date.now().toString(36)}_${Math.random().toString(36).slice(2, 6)}`;
  const clone = value => JSON.parse(JSON.stringify(value));
  const clamp = (v, min, max) => Math.min(max, Math.max(min, v));
  const round = (v, n = 4) => Number(Number(v || 0).toFixed(n));
  const escapeHtml = value => String(value ?? '').replace(/[&<>'"]/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));

  const PRESETS = [
    {name:'设计分辨率 1528×1029', w:1528, h:1029},
    {name:'横屏 1920×1080', w:1920, h:1080},
    {name:'横屏 1280×720', w:1280, h:720},
    {name:'截图 1080×606', w:1080, h:606},
    {name:'平板 1366×768', w:1366, h:768},
    {name:'手机横屏 844×390', w:844, h:390},
    {name:'手机竖屏 390×844', w:390, h:844}
  ];
  const STATE_NAMES = {normal:'正常', hover:'悬停', pressed:'按下', disabled:'禁用'};
  const DEFAULT_STATE = () => ({image:'', color:'#ffffff', opacity:1, outlineColor:'#f6b54b', outlineWidth:0, glow:0});
  const defaultEntity = type => ({
    id: uid(type === 'clue' ? 'clue' : 'ui'), name:type === 'clue' ? '新线索物件' : '新 UI', type,
    x:type === 'clue' ? .38 : .72, y:type === 'clue' ? .52 : .08,
    w:type === 'clue' ? .18 : .2, h:type === 'clue' ? .22 : .09,
    rotation:0, opacity:1, visible:true, locked:false, zIndex:type === 'clue' ? 50 : 2000,
    anchor:'top-left', fit:'contain', image:'', text:type === 'ui' ? 'UI 文本' : '', fontSize:28,
    textColor:'#ffffff', backgroundColor:'rgba(0,0,0,0)', borderRadius:0,
    outline:{enabled:type === 'clue', color:'#ffd76a', width:2, glow:8, image:''},
    clue:{clueId:'', dialogueId:'', interactText:'', misleading:false, spriteTrim:false},
    ui:{component:type === 'ui' ? 'panel' : '', adapt:'normalized', pointerEvents:'auto', state:'normal'},
    states:{normal:DEFAULT_STATE(), hover:DEFAULT_STATE(), pressed:DEFAULT_STATE(), disabled:DEFAULT_STATE()}
  });
  const defaultProject = () => ({
    schemaVersion:1, exporter:'Yishi Scene UI Editor', projectName:'未命名布局', sceneId:'scene_id', sceneTitle:'新场景',
    coordinateSystem:'normalized', design:{width:1528,height:1029,safeArea:{left:.03,top:.04,right:.03,bottom:.04},grid:16},
    screens:[{id:'s1',title:'页面 1',background:{image:'',fit:'cover',position:'center center',color:'#252a33'},entities:[]}],
    uiElements:[], dialogues:[], assets:[], meta:{createdAt:new Date().toISOString(),updatedAt:new Date().toISOString()}
  });
  const DIALOGUE_FIELDS=['dialogue_id','line_no','speaker','portrait','clue','text','background'];
  function parseCsv(text){
    text=String(text||'').replace(/^\\uFEFF/,''); const rows=[]; let row=[],cell='',quoted=false;
    for(let i=0;i<text.length;i++){const c=text[i],n=text[i+1];if(c==='"'){if(quoted&&n==='"'){cell+='"';i++}else quoted=!quoted}else if(c===','&&!quoted){row.push(cell);cell=''}else if((c==='\\n'||c==='\\r')&&!quoted){if(c==='\\r'&&n==='\\n')i++;row.push(cell);if(row.some(v=>v.trim()!==''))rows.push(row);row=[];cell=''}else cell+=c} if(cell!==''||row.length){row.push(cell);if(row.some(v=>v.trim()!==''))rows.push(row)}
    if(!rows.length)return []; const headers=rows[0].map(v=>v.trim()); return rows.slice(1).map((r,i)=>{const o={};headers.forEach((h,j)=>o[h]=r[j]??'');o._row=i+2;return o}).filter(o=>DIALOGUE_FIELDS.some(k=>o[k]));
  }
  function normalizeDialogue(row){return {dialogue_id:row.dialogue_id||row.id||'',line_no:Number(row.line_no||row.lineNo||1),speaker:row.speaker||'',portrait:row.portrait||'',clue:row.clue||'',text:row.text||'',background:row.background||''}}


  let project = defaultProject();
  let currentScreenId = 's1';
  let selectedId = null;
  let zoom = 1;
  let previewState = 'normal';
  let showGrid = true, snapEnabled = true, showSafe = true;
  let history = [], future = [], drag = null, dirty = false;

  const el = {
    viewport:$('#viewport'), stage:$('#stage'), stageWrap:$('#stageWrap'), stageBg:$('#stageBg'), stageGrid:$('#stageGrid'), safeArea:$('#safeArea'),
    hierarchy:$('#hierarchy'), inspector:$('#inspector'), screenSelect:$('#screenSelect'), assetList:$('#assetList'), jsonText:$('#jsonText'), jsonPanel:$('#jsonPanel'),
    crumb:$('#screenCrumb'), count:$('#entityCount'), cursor:$('#cursorPos'), saveState:$('#saveState'), zoomRange:$('#zoomRange'), zoomLabel:$('#zoomLabel'),
    jsonFile:$('#jsonFile'), csvFile:$('#csvFile'), imageFile:$('#imageFile'), toasts:$('#toasts'), marquee:$('#selectionMarquee'),
    dialoguePanel:$('#dialoguePanel'), dialogueBody:$('#dialogueBody')
  };

  function currentScreen(){ return project.screens.find(s => s.id === currentScreenId) || project.screens[0]; }
  function selected(){ return currentScreen()?.entities.find(e => e.id === selectedId) || (project.uiElements||[]).find(e => e.id === selectedId) || null; }
  function entityList(e){ return e?.type==='ui' ? (project.uiElements||[]) : currentScreen().entities; }
  function markDirty(value = true){ dirty = value; project.meta.updatedAt = new Date().toISOString(); el.saveState.textContent = value ? '未保存更改' : '已保存'; el.saveState.classList.toggle('ok', !value); }
  function toast(message, type = ''){ const t=document.createElement('div'); t.className=`toast ${type}`; t.textContent=message; el.toasts.append(t); setTimeout(()=>t.remove(),2600); }
  function snapshot(){ history.push(JSON.stringify(project)); if(history.length>80) history.shift(); future=[]; }
  function restore(text){ project=JSON.parse(text); currentScreenId=project.screens[0]?.id || ''; selectedId=null; renderAll(); markDirty(); }
  function mutate(fn, rerender = true){ snapshot(); fn(); markDirty(); if(rerender) renderAll(); }

  function buildPresetOptions(){ el.screenSelect.innerHTML=''; $('#viewportPreset').innerHTML=PRESETS.map((p,i)=>`<option value="${i}">${p.name}</option>`).join(''); }
  function applyPreset(index){
    const p=PRESETS[Number(index)] || PRESETS[0], oldW=project.design.width, oldH=project.design.height;
    snapshot();
    [...project.screens.flatMap(screen=>screen.entities),...(project.uiElements||[])].forEach(e=>{
      const mode=e.ui?.adapt||'normalized', anchor=e.anchor||'top-left';
      const oldPx={x:e.x*oldW,y:e.y*oldH,w:e.w*oldW,h:e.h*oldH};
      if(mode==='fixed-width'||mode==='fixed-size')e.w=oldPx.w/p.w;
      if(mode==='fixed-height'||mode==='fixed-size')e.h=oldPx.h/p.h;
      if(mode==='fixed-width'||mode==='fixed-size'){
        if(anchor.includes('right'))e.x=1-(oldW-oldPx.x-oldPx.w)/p.w-e.w;
        else if(anchor.includes('center'))e.x=.5+(oldPx.x+oldPx.w/2-oldW/2)/p.w-e.w/2;
        else e.x=oldPx.x/p.w;
      }
      if(mode==='fixed-height'||mode==='fixed-size'){
        if(anchor.includes('bottom'))e.y=1-(oldH-oldPx.y-oldPx.h)/p.h-e.h;
        else if(anchor==='center')e.y=.5+(oldPx.y+oldPx.h/2-oldH/2)/p.h-e.h/2;
        else e.y=oldPx.y/p.h;
      }
      if(mode==='safe-area'){
        const sa=project.design.safeArea;e.x=clamp(e.x,sa.left,1-sa.right-e.w);e.y=clamp(e.y,sa.top,1-sa.bottom-e.h);
      }
      e.x=clamp(e.x,0,Math.max(0,1-e.w));e.y=clamp(e.y,0,Math.max(0,1-e.h));
    });
    project.design.width=p.w;project.design.height=p.h;markDirty();renderStage();fitStage();renderInspector();
  }
  function fitStage(){ const w=project.design.width,h=project.design.height; const box=el.viewport.getBoundingClientRect(); zoom=clamp(Math.min((box.width-100)/w,(box.height-120)/h),.2,2); syncZoom(); renderStageGeometry(); }
  function syncZoom(){ el.zoomRange.value=Math.round(zoom*100); el.zoomLabel.textContent=`${Math.round(zoom*100)}%`; }
  function renderStageGeometry(){ const {width:w,height:h,grid}=project.design; el.stage.style.width=`${w}px`; el.stage.style.height=`${h}px`; el.stage.style.transform=`scale(${zoom})`; el.stageWrap.style.width=`${w*zoom}px`; el.stageWrap.style.height=`${h*zoom}px`; el.stageGrid.style.backgroundSize=`${grid}px ${grid}px`; }

  function renderAll(){ renderScreenSelect(); renderHierarchy(); renderAssets(); renderStage(); renderInspector(); renderDialogues(); refreshJson(); }
  function renderScreenSelect(){ el.screenSelect.innerHTML=project.screens.map(s=>`<option value="${escapeHtml(s.id)}" ${s.id===currentScreenId?'selected':''}>${escapeHtml(s.title)} · ${escapeHtml(s.id)}</option>`).join(''); }
  function renderHierarchy(){ const s=currentScreen(); if(!s)return; const q=$('#layerSearch').value.trim().toLowerCase(); const filtered=e=>!q||`${e.name} ${e.id} ${e.type}`.toLowerCase().includes(q); const row=(e,kind)=>`<div class="tree-item ${e.id===selectedId?'selected':''}" data-id="${escapeHtml(e.id)}"><span class="kind">${kind}</span><span class="name">${escapeHtml(e.name)}</span><button class="mini ${e.visible?'on':''}" data-action="visible" title="显示">◉</button><button class="mini ${e.locked?'on':''}" data-action="lock" title="锁定">◆</button></div>`;
    const clues=s.entities.filter(e=>e.type==='clue'&&filtered(e)).sort((a,b)=>b.zIndex-a.zIndex); const ui=(project.uiElements||[]).filter(e=>filtered(e)).sort((a,b)=>b.zIndex-a.zIndex);
    el.hierarchy.innerHTML=`<div class="tree-item" data-root="background"><span class="kind">BG</span><span class="name">背景 · ${escapeHtml(s.background.image||'未设置')}</span></div><div class="tree-item"><span class="kind">▾</span><span class="name">线索物件</span><span class="chip">${clues.length}</span></div><div class="tree-indent">${clues.map(e=>row(e,'◇')).join('')}</div><div class="tree-item"><span class="kind">▾</span><span class="name">UI</span><span class="chip">${ui.length}</span></div><div class="tree-indent">${ui.map(e=>row(e,'▣')).join('')}</div>`;
    $$('.tree-item[data-id]',el.hierarchy).forEach(item=>item.addEventListener('click',ev=>{ const e=[...currentScreen().entities,...(project.uiElements||[])].find(x=>x.id===item.dataset.id); if(!e)return; if(ev.target.dataset.action==='visible'){mutate(()=>e.visible=!e.visible);return} if(ev.target.dataset.action==='lock'){mutate(()=>e.locked=!e.locked);return} selectedId=item.dataset.id; renderAll(); }));
    $('[data-root="background"]',el.hierarchy)?.addEventListener('click',()=>{selectedId='__background';renderAll()});
    el.count.textContent=`${s.entities.length} 个元素`;
  }

  function renderAssets(){ if(!project.assets.length){el.assetList.innerHTML='<div class="asset-empty">导入 PNG/JPG/WebP 后，可双击素材添加物件。<br>也可以在 Inspector 直接输入项目资源路径。</div>';return} el.assetList.innerHTML=project.assets.map(a=>`<div class="asset-item" data-id="${a.id}"><img class="asset-thumb" src="${a.dataUrl||a.path}" alt=""><div class="asset-meta"><div class="asset-name">${escapeHtml(a.name)}</div><div class="asset-path">${escapeHtml(a.path||'内嵌预览')}</div></div></div>`).join(''); $$('.asset-item',el.assetList).forEach(x=>x.addEventListener('dblclick',()=>{const a=project.assets.find(v=>v.id===x.dataset.id); addEntity('clue',a)})); }

  function entityImage(e){ const st=e.states?.[previewState]||e.states?.normal; return (previewState!=='normal'&&st?.image)||e.image||e.states?.normal?.image||''; }
  function renderStage(){ const s=currentScreen(); if(!s)return; renderStageGeometry(); el.crumb.textContent=`${project.sceneTitle} / ${s.title}`; el.stageBg.src=resolveAsset(s.background.image); el.stageBg.style.objectFit=s.background.fit||'cover'; el.stageBg.style.objectPosition=s.background.position||'center center'; el.stage.style.background=s.background.color||'#252a33'; el.stageGrid.classList.toggle('show',showGrid); el.safeArea.style.display=showSafe?'block':'none'; const sa=project.design.safeArea; Object.assign(el.safeArea.style,{left:`${sa.left*100}%`,top:`${sa.top*100}%`,right:`${sa.right*100}%`,bottom:`${sa.bottom*100}%`});
    $$('.entity',el.stage).forEach(n=>n.remove()); [...s.entities,...(project.uiElements||[])].sort((a,b)=>a.zIndex-b.zIndex).forEach(renderEntity);
  }
  function resolveAsset(path){
    if(!path)return '';
    const local=project.assets.find(a=>a.path===path||a.id===path)?.dataUrl;
    if(local)return local;
    if(/^assets\//.test(path))return `../${path}`;
    return path;
  }
  function renderEntity(e){ const d=document.createElement('div'); d.className=`entity ${e.type==='ui'&&e.ui?.component==='label'?'ui-text':''} ${e.id===selectedId?'selected':''} ${e.locked?'locked':''} ${!e.visible?'hidden-editor':''}`; d.dataset.id=e.id; const state=e.states?.[previewState]||e.states?.normal||DEFAULT_STATE(); Object.assign(d.style,{left:`${e.x*100}%`,top:`${e.y*100}%`,width:`${e.w*100}%`,height:`${e.h*100}%`,zIndex:e.zIndex,opacity:e.visible?e.opacity:.22,transform:`rotate(${e.rotation}deg)`,backgroundColor:e.backgroundColor||'transparent',borderRadius:`${e.borderRadius||0}px`,color:e.textColor||'#fff',fontSize:`${e.fontSize||28}px`,border:`${state.outlineWidth||0}px solid ${state.outlineColor||'transparent'}`,boxShadow:state.glow?`0 0 ${state.glow}px ${state.outlineColor||'#fff'}`:'none'});
    const clueOutline=e.type==='clue'&&e.outline?.enabled?e.outline:null;
    const outlineWidth=state.outlineWidth||clueOutline?.width||0, outlineColor=state.outlineWidth?state.outlineColor:(clueOutline?.color||'transparent'), glow=state.glow||clueOutline?.glow||0;
    d.style.opacity=e.visible?e.opacity*(state.opacity??1):.22;d.style.border=`${outlineWidth}px solid ${outlineColor}`;d.style.boxShadow=glow?`0 0 ${glow}px ${outlineColor}`:'none';
    const img=entityImage(e); if(img){const im=document.createElement('img');im.src=resolveAsset(img);im.style.objectFit=e.fit||'contain';d.append(im);if(state.color&&state.color.toLowerCase()!=='#ffffff'){const tint=document.createElement('span');tint.className='state-tint';tint.style.backgroundColor=state.color;d.append(tint)}} else if(e.text){d.append(document.createTextNode(e.text))} else {d.style.background=d.style.backgroundColor==='transparent'||d.style.backgroundColor==='rgba(0, 0, 0, 0)'?'#58617466':d.style.backgroundColor}
    if(e.type==='clue'&&e.outline?.enabled&&e.outline.image&&(e.id===selectedId||previewState!=='normal')){const oi=document.createElement('img');oi.className='outline-img';oi.src=resolveAsset(e.outline.image);oi.style.objectFit=e.fit||'contain';oi.style.color=e.outline.color||'#ffd76a';d.append(oi)}
    d.insertAdjacentHTML('beforeend',`<span class="badge">${escapeHtml(e.name)}</span><i class="resize-handle nw" data-h="nw"></i><i class="resize-handle ne" data-h="ne"></i><i class="resize-handle sw" data-h="sw"></i><i class="resize-handle se" data-h="se"></i>`); d.addEventListener('pointerdown',startTransform); el.stage.append(d);
  }

  function startTransform(ev){ const node=ev.currentTarget,e=selectedId===node.dataset.id?selected():[...currentScreen().entities,...(project.uiElements||[])].find(x=>x.id===node.dataset.id); if(!e)return; selectedId=e.id; renderHierarchy(); renderInspector(); if(e.locked)return; ev.preventDefault(); node.setPointerCapture(ev.pointerId); const rect=el.stage.getBoundingClientRect(); drag={e,node,handle:ev.target.dataset.h||'move',startX:ev.clientX,startY:ev.clientY,base:clone({x:e.x,y:e.y,w:e.w,h:e.h}),stageW:rect.width,stageH:rect.height,moved:false}; snapshot(); node.classList.add('selected'); node.addEventListener('pointermove',moveTransform); node.addEventListener('pointerup',endTransform,{once:true}); }
  function snap(v,axis){ if(!snapEnabled)return v; const size=axis==='x'?project.design.width:project.design.height; return Math.round(v*size/project.design.grid)*project.design.grid/size; }
  function moveTransform(ev){ if(!drag)return; const dx=(ev.clientX-drag.startX)/drag.stageW,dy=(ev.clientY-drag.startY)/drag.stageH,b=drag.base,e=drag.e; if(Math.abs(dx)+Math.abs(dy)>.0001)drag.moved=true; if(drag.handle==='move'){e.x=clamp(snap(b.x+dx,'x'),0,1-e.w);e.y=clamp(snap(b.y+dy,'y'),0,1-e.h)}else{let x=b.x,y=b.y,w=b.w,h=b.h;if(drag.handle.includes('e'))w=b.w+dx;if(drag.handle.includes('s'))h=b.h+dy;if(drag.handle.includes('w')){x=b.x+dx;w=b.w-dx}if(drag.handle.includes('n')){y=b.y+dy;h=b.h-dy}e.x=clamp(snap(x,'x'),0,.99);e.y=clamp(snap(y,'y'),0,.99);e.w=clamp(snap(w,'x'),.01,1-e.x);e.h=clamp(snap(h,'y'),.01,1-e.y)} updateEntityNode(drag.node,e); updateTransformInspector(e); markDirty(); }
  function endTransform(ev){ const node=ev.currentTarget;node.removeEventListener('pointermove',moveTransform);if(!drag?.moved)history.pop();drag=null;renderAll() }
  function updateEntityNode(node,e){Object.assign(node.style,{left:`${e.x*100}%`,top:`${e.y*100}%`,width:`${e.w*100}%`,height:`${e.h*100}%`})}
  function updateTransformInspector(e){['x','y','w','h'].forEach(k=>{const n=$(`[data-prop="${k}"]`,el.inspector);if(n)n.value=round(e[k],4)})}

  function field(label,control,cls=''){return `<div class="field ${cls}"><label>${label}</label><div class="control">${control}</div></div>`}
  function inp(prop,val,type='text',extra=''){return `<input type="${type}" data-prop="${prop}" value="${escapeHtml(val)}" ${extra}>`}
  function sel(prop,val,items){return `<select data-prop="${prop}">${items.map(x=>`<option value="${x[0]}" ${x[0]===val?'selected':''}>${x[1]}</option>`).join('')}</select>`}
  function section(title,body){return `<section class="section"><div class="section-head">${title}</div><div class="section-content">${body}</div></section>`}
  function bindSections(){ $$('.section-head',el.inspector).forEach(h=>h.onclick=()=>h.parentElement.classList.toggle('collapsed')); }
  function renderInspector(){ const s=currentScreen(); if(selectedId==='__background'){renderBackgroundInspector(s);return} const e=selected(); if(!e){el.inspector.innerHTML='<div class="empty-inspector"><strong>未选择对象</strong>从左侧层级或画布选择元素。<br>双击素材可快速创建线索物件。</div>';return}
    const transform=field('位置 X / Y',`${inp('x',round(e.x),'number','step="0.001" min="0" max="1"')}${inp('y',round(e.y),'number','step="0.001" min="0" max="1"')}`,'row2')+field('宽度 / 高度',`${inp('w',round(e.w),'number','step="0.001" min="0.001" max="1"')}${inp('h',round(e.h),'number','step="0.001" min="0.001" max="1"')}`,'row2')+field('旋转 / 层级',`${inp('rotation',e.rotation,'number','step="1"')}${inp('zIndex',e.zIndex,'number','step="1"')}`,'row2')+field('锚点',sel('anchor',e.anchor,[['top-left','左上'],['top-center','上中'],['top-right','右上'],['center','中心'],['bottom-left','左下'],['bottom-center','下中'],['bottom-right','右下']]))+field('适配',sel('ui.adapt',e.ui?.adapt||'normalized',[['normalized','归一化比例'],['safe-area','安全区约束'],['fixed-size','固定像素尺寸'],['fixed-width','固定宽度'],['fixed-height','固定高度'],['stretch','拉伸']]))+`<div class="hint">切换顶部预览分辨率可验证锚点、固定尺寸及安全区适配。</div>`;
    const basic=field('名称',inp('name',e.name))+field('ID',inp('id',e.id))+field('类型',`<span class="chip">${e.type==='clue'?'线索物件':'UI 元素'}</span>`)+field('显示 / 锁定',`<div class="check-row"><label><input type="checkbox" data-prop="visible" ${e.visible?'checked':''}> 显示</label><label><input type="checkbox" data-prop="locked" ${e.locked?'checked':''}> 锁定</label></div>`)+field('透明度',inp('opacity',e.opacity,'number','step="0.05" min="0" max="1"'));
    const visual=field('图片',`<div class="inline">${inp('image',e.image)}<button class="small-btn" data-pick="image">选择</button></div>`)+field('填充模式',sel('fit',e.fit,[['contain','Contain'],['cover','Cover'],['fill','Fill']]))+field('背景色',inp('backgroundColor',e.backgroundColor))+field('圆角',inp('borderRadius',e.borderRadius,'number','min="0"'));
    let specific=''; if(e.type==='clue')specific=field('线索 ID',inp('clue.clueId',e.clue.clueId))+field('对话 ID',inp('clue.dialogueId',e.clue.dialogueId))+field('交互文本',`<textarea data-prop="clue.interactText">${escapeHtml(e.clue.interactText)}</textarea>`)+field('误导 / 裁切',`<div class="check-row"><label><input type="checkbox" data-prop="clue.misleading" ${e.clue.misleading?'checked':''}> 误导</label><label><input type="checkbox" data-prop="clue.spriteTrim" ${e.clue.spriteTrim?'checked':''}> Trim</label></div>`)+field('描边图片',`<div class="inline">${inp('outline.image',e.outline.image)}<button class="small-btn" data-pick="outline.image">选择</button></div>`)+field('描边',`<div class="control"><div class="inline"><input type="checkbox" data-prop="outline.enabled" ${e.outline.enabled?'checked':''}>${inp('outline.color',e.outline.color,'color')}${inp('outline.width',e.outline.width,'number','min="0"')}</div></div>`)+field('发光',inp('outline.glow',e.outline.glow,'number','min="0"'));
    else specific=field('组件',sel('ui.component',e.ui.component,[['panel','Panel'],['button','Button'],['label','Label'],['icon','Icon'],['progress','Progress']]))+field('文字',inp('text',e.text))+field('字号 / 颜色',`${inp('fontSize',e.fontSize,'number','min="1"')}${inp('textColor',e.textColor,'color')}`,'row2')+field('事件穿透',sel('ui.pointerEvents',e.ui.pointerEvents,[['auto','Auto'],['none','None'],['box-none','Box None']]));
    const state=e.states?.[previewState]||DEFAULT_STATE(); const states=`<div class="state-tabs">${Object.entries(STATE_NAMES).map(([k,v])=>`<button class="state-tab ${k===previewState?'active':''}" data-state="${k}">${v}</button>`).join('')}</div>`+field('状态图片',`<div class="inline">${inp(`states.${previewState}.image`,state.image)}<button class="small-btn" data-pick="states.${previewState}.image">选择</button></div>`)+field('色调 / 透明度',`${inp(`states.${previewState}.color`,state.color,'color')}${inp(`states.${previewState}.opacity`,state.opacity,'number','step="0.05" min="0" max="1"')}`,'row2')+field('轮廓色 / 宽',`${inp(`states.${previewState}.outlineColor`,state.outlineColor,'color')}${inp(`states.${previewState}.outlineWidth`,state.outlineWidth,'number','min="0"')}`,'row2')+field('发光半径',inp(`states.${previewState}.glow`,state.glow,'number','min="0"'));
    el.inspector.innerHTML=section('对象',basic)+section('Rect Transform',transform)+section('视觉',visual)+section(e.type==='clue'?'线索交互':'UI 配置',specific)+section('状态',states); bindInspector(e); }

  function renderBackgroundInspector(s){ const b=s.background; const design=project.design,sa=design.safeArea; el.inspector.innerHTML=section('项目',field('项目名',inp('projectName',project.projectName))+field('场景 ID',inp('sceneId',project.sceneId))+field('场景标题',inp('sceneTitle',project.sceneTitle)))+section('当前页面',field('页面 ID',inp('screen.id',s.id))+field('页面标题',inp('screen.title',s.title)))+section('背景',field('图片路径',`<div class="inline">${inp('background.image',b.image)}<button class="small-btn" data-pick="background.image">选择</button></div>`)+field('填充',sel('background.fit',b.fit,[['cover','Cover'],['contain','Contain'],['fill','Fill']]))+field('对齐',sel('background.position',b.position,[['center center','居中'],['left center','左中'],['right center','右中'],['center top','中上'],['center bottom','中下']]))+field('底色',inp('background.color',b.color,'color')))+section('画布与适配',field('设计尺寸',`${inp('design.width',design.width,'number','min="1"')}${inp('design.height',design.height,'number','min="1"')}`,'row2')+field('网格',inp('design.grid',design.grid,'number','min="1"'))+field('安全区 L / T',`${inp('design.safeArea.left',sa.left,'number','step="0.01" min="0" max="0.5"')}${inp('design.safeArea.top',sa.top,'number','step="0.01" min="0" max="0.5"')}`,'row2')+field('安全区 R / B',`${inp('design.safeArea.right',sa.right,'number','step="0.01" min="0" max="0.5"')}${inp('design.safeArea.bottom',sa.bottom,'number','step="0.01" min="0" max="0.5"')}`,'row2')); bindInspector(null); }

  function getPath(obj,path){return path.split('.').reduce((v,k)=>v?.[k],obj)}
  function setPath(obj,path,value){const ks=path.split('.');let cur=obj;ks.slice(0,-1).forEach(k=>cur=cur[k]??(cur[k]={}));cur[ks.at(-1)]=value}
  function bindInspector(entity){ bindSections(); $$('[data-prop]',el.inspector).forEach(input=>{ const event=input.type==='text'||input.tagName==='TEXTAREA'?'change':'input'; input.addEventListener(event,()=>{let root=entity||project,path=input.dataset.prop;if(path.startsWith('screen.')){root=currentScreen();path=path.slice(7)}else if(path.startsWith('background.')){root=currentScreen().background;path=path.slice(11)}else if(path.startsWith('design.')){root=project.design;path=path.slice(7)}let value=input.type==='checkbox'?input.checked:input.value;if(input.type==='number')value=Number(value);snapshot();setPath(root,path,value);if(path==='id'&&root===currentScreen())currentScreenId=value;if(path==='id'&&entity)selectedId=value;markDirty();renderAll()}) }); $$('[data-pick]',el.inspector).forEach(btn=>btn.onclick=()=>openAssetPicker(btn.dataset.pick)); $$('.state-tab',el.inspector).forEach(btn=>btn.onclick=()=>{previewState=btn.dataset.state;$('#statePreviewBtn').textContent=`预览状态：${STATE_NAMES[previewState]}`;renderStage();renderInspector()}); }

  function openAssetPicker(prop){ if(!project.assets.length){el.imageFile.click();toast('请先导入图片素材','warn');return} const body=`<div class="assets" style="height:300px">${project.assets.map(a=>`<div class="asset-item" data-modal-asset="${a.id}"><img class="asset-thumb" src="${a.dataUrl}"><div class="asset-meta"><div class="asset-name">${escapeHtml(a.name)}</div><div class="asset-path">${escapeHtml(a.path)}</div></div></div>`).join('')}</div>`; showModal('选择素材',body,()=>{},false); $$('[data-modal-asset]').forEach(row=>row.onclick=()=>{ const a=project.assets.find(x=>x.id===row.dataset.modalAsset); applyAssetProp(prop,a.path||a.dataUrl); hideModal(); }); }
  function applyAssetProp(prop,value){ snapshot(); if(prop.startsWith('background.'))setPath(currentScreen().background,prop.slice(11),value);else setPath(selected(),prop,value);markDirty();renderAll(); }
  function showModal(title,body,onOk,showOk=true){$('#modalTitle').textContent=title;$('#modalBody').innerHTML=body;$('#modalOk').style.display=showOk?'inline-flex':'none';$('#modalMask').classList.add('show');$('#modalOk').onclick=()=>{onOk();hideModal()}}
  function hideModal(){$('#modalMask').classList.remove('show')}

  function addEntity(type,asset){ mutate(()=>{const e=defaultEntity(type); if(asset){e.name=asset.name.replace(/\.[^.]+$/,'');e.image=asset.path||asset.dataUrl;e.states.normal.image=e.image} (type==='ui'?(project.uiElements||(project.uiElements=[])):currentScreen().entities).push(e);selectedId=e.id}); }
  function duplicateSelected(){const e=selected();if(!e)return;mutate(()=>{const c=clone(e);c.id=uid(e.type);c.name=`${e.name} 副本`;c.x=clamp(c.x+.02,0,1-c.w);c.y=clamp(c.y+.02,0,1-c.h);entityList(e).push(c);selectedId=c.id})}
  function deleteSelected(){if(selectedId==='__background'||!selected())return;mutate(()=>{const list=entityList(selected());const i=list.findIndex(e=>e.id===selectedId);if(i>=0)list.splice(i,1);selectedId=null})}
  function addScreen(copyFrom){ mutate(()=>{const base=copyFrom?clone(currentScreen()):{id:uid('s'),title:`页面 ${project.screens.length+1}`,background:{image:'',fit:'cover',position:'center center',color:'#252a33'},entities:[]};base.id=uid('s');if(copyFrom)base.title+= ' 副本';project.screens.push(base);currentScreenId=base.id;selectedId='__background'}) }
  function deleteScreen(){if(project.screens.length<=1){toast('至少保留一个页面','warn');return} mutate(()=>{project.screens=project.screens.filter(s=>s.id!==currentScreenId);currentScreenId=project.screens[0].id;selectedId=null})}

  function cleanForExport(){
    const out=clone(project);out.meta.updatedAt=new Date().toISOString();
    out.assets=out.assets.map(({dataUrl,...asset})=>asset);
    out.screens.forEach(s=>s.entities.forEach(e=>{e.pixelRect={x:round(e.x*out.design.width,2),y:round(e.y*out.design.height,2),w:round(e.w*out.design.width,2),h:round(e.h*out.design.height,2)}}));
    out.uiElements.forEach(e=>{e.pixelRect={x:round(e.x*out.design.width,2),y:round(e.y*out.design.height,2),w:round(e.w*out.design.width,2),h:round(e.h*out.design.height,2)}});
    return out;
  }
  function refreshJson(){el.jsonText.value=JSON.stringify(cleanForExport(),null,2)}
  function downloadJson(){const data=JSON.stringify(cleanForExport(),null,2),blob=new Blob([data],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=`${project.sceneId||'scene'}-layout.json`;a.click();URL.revokeObjectURL(a.href);markDirty(false);toast('JSON 已导出')}
  function importProject(data){if(!data||!Array.isArray(data.screens)||!data.design)throw new Error('缺少 design 或 screens');project=data;project.assets??=[];project.uiElements??=[];project.dialogues??=[];project.meta??={};project.design.safeArea??={left:.03,top:.04,right:.03,bottom:.04};project.design.grid??=16;project.screens.forEach(s=>{s.entities??=[];s.background??={image:'',fit:'cover',position:'center center',color:'#252a33'};s.entities.forEach(normalizeEntity)});project.uiElements.forEach(normalizeEntity);currentScreenId=project.screens[0].id;selectedId=null;history=[];future=[];renderAll();fitStage();markDirty(false)}
  function normalizeEntity(e){const d=defaultEntity(e.type);for(const[k,v]of Object.entries(d))if(e[k]===undefined)e[k]=v;e.outline={...d.outline,...e.outline};e.clue={...d.clue,...e.clue};e.ui={...d.ui,...e.ui};e.states={normal:{...DEFAULT_STATE(),...e.states?.normal},hover:{...DEFAULT_STATE(),...e.states?.hover},pressed:{...DEFAULT_STATE(),...e.states?.pressed},disabled:{...DEFAULT_STATE(),...e.states?.disabled}}}
  function readImages(files){[...files].forEach(file=>{const reader=new FileReader();reader.onload=()=>{const path=`assets/image/${file.name}`;project.assets.push({id:uid('asset'),name:file.name,path,dataUrl:reader.result,width:0,height:0});const im=new Image();im.onload=()=>{const a=project.assets.at(-1);a.width=im.width;a.height=im.height;renderAssets()};im.src=reader.result;markDirty();renderAssets()};reader.readAsDataURL(file)})}
  function dialogueCsvExport(){
    const rows=[DIALOGUE_FIELDS,...(project.dialogues||[]).map(d=>DIALOGUE_FIELDS.map(k=>d[k]??''))];
    const csv=rows.map(row=>row.map(v=>`"${String(v).replace(/"/g,'""')}"`).join(',')).join('\\r\\n');
    const blob=new Blob([csv],{type:'text/csv;charset=utf-8'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='dialogues.csv';a.click();URL.revokeObjectURL(a.href);toast('台词 CSV 已导出');
  }
  function dialogueJsonExport(){
    const grouped={};(project.dialogues||[]).forEach(d=>(grouped[d.dialogue_id]??=[]).push({lineNo:d.line_no,speaker:d.speaker,portrait:d.portrait,clue:d.clue,text:d.text,background:d.background}));
    const data={schemaVersion:1,type:'dialogues',source:'dialogues.csv',dialogues:grouped,rows:project.dialogues||[]};const blob=new Blob([JSON.stringify(data,null,2)],{type:'application/json'}),a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download='dialogues.json';a.click();URL.revokeObjectURL(a.href);toast('台词 JSON 已导出');
  }
  function renderDialogues(){
    const q=($('#dialogueSearch')?.value||'').toLowerCase();const rows=(project.dialogues||[]).filter(d=>`${d.dialogue_id} ${d.speaker} ${d.text}`.toLowerCase().includes(q));
    el.dialogueBody.innerHTML=rows.length?rows.map((d,i)=>`<tr data-dialogue-index="${project.dialogues.indexOf(d)}"><td><input data-dialogue="dialogue_id" value="${escapeHtml(d.dialogue_id)}"></td><td><input type="number" data-dialogue="line_no" value="${d.line_no}"></td><td><input data-dialogue="speaker" value="${escapeHtml(d.speaker)}"></td><td><textarea data-dialogue="text">${escapeHtml(d.text)}</textarea></td><td><input data-dialogue="clue" value="${escapeHtml(d.clue)}"></td><td><button class="mini danger" data-remove-dialogue>×</button></td></tr>`).join(''):'<tr><td colspan="6" class="dialogue-empty">还没有台词。点击“导入台词 CSV”开始。</td></tr>';
    $$('[data-dialogue]',el.dialogueBody).forEach(input=>input.addEventListener(input.tagName==='TEXTAREA'?'change':'change',()=>{const d=project.dialogues[Number(input.closest('tr').dataset.dialogueIndex)];snapshot();d[input.dataset.dialogue]=input.type==='number'?Number(input.value):input.value;markDirty()}));
    $$('[data-remove-dialogue]',el.dialogueBody).forEach(btn=>btn.onclick=()=>{mutate(()=>project.dialogues.splice(Number(btn.closest('tr').dataset.dialogueIndex),1));renderDialogues()});
  }
  function importDialogueCsv(text){const rows=parseCsv(text);if(!rows.length)throw new Error('CSV 没有可读取的数据');const missing=DIALOGUE_FIELDS.filter(k=>k!=='portrait'&&k!=='clue'&&k!=='background'&&!Object.prototype.hasOwnProperty.call(rows[0],k));if(missing.length)throw new Error(`缺少字段：${missing.join(', ')}`);mutate(()=>{project.dialogues=rows.map(normalizeDialogue)});renderDialogues();toast(`已导入 ${rows.length} 条台词`)}

  function bindEvents(){
    $('#addClueBtn').onclick=()=>addEntity('clue');$('#addUiBtn').onclick=()=>addEntity('ui');$('#duplicateBtn').onclick=duplicateSelected;$('#deleteBtn').onclick=deleteSelected;
    $('#addScreenBtn').onclick=()=>addScreen(false);$('#duplicateScreenBtn').onclick=()=>addScreen(true);$('#deleteScreenBtn').onclick=deleteScreen;
    el.screenSelect.onchange=()=>{currentScreenId=el.screenSelect.value;selectedId=null;renderAll()};$('#layerSearch').oninput=renderHierarchy;
    $('#viewportPreset').onchange=e=>applyPreset(e.target.value);$('#fitBtn').onclick=fitStage;el.zoomRange.oninput=e=>{zoom=Number(e.target.value)/100;syncZoom();renderStageGeometry()};
    $('#gridBtn').onclick=e=>{showGrid=!showGrid;e.currentTarget.classList.toggle('active',showGrid);renderStage()};$('#snapBtn').onclick=e=>{snapEnabled=!snapEnabled;e.currentTarget.classList.toggle('active',snapEnabled)};$('#safeBtn').onclick=e=>{showSafe=!showSafe;e.currentTarget.classList.toggle('active',showSafe);renderStage()};
    $('#statePreviewBtn').onclick=()=>{const keys=Object.keys(STATE_NAMES),i=(keys.indexOf(previewState)+1)%keys.length;previewState=keys[i];$('#statePreviewBtn').textContent=`预览状态：${STATE_NAMES[previewState]}`;renderStage();renderInspector()};
    $('#addAssetBtn').onclick=()=>el.imageFile.click();el.imageFile.onchange=e=>{readImages(e.target.files);e.target.value=''};
    $('#exportBtn').onclick=downloadJson;$('#exportDialogueBtn').onclick=dialogueJsonExport;$('#importCsvBtn').onclick=()=>el.csvFile.click();el.csvFile.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{importDialogueCsv(r.result)}catch(err){toast(`CSV 导入失败：${err.message}`,'error')}};r.readAsText(f);e.target.value=''};$('#importBtn').onclick=()=>el.jsonFile.click();el.jsonFile.onchange=e=>{const f=e.target.files[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{importProject(JSON.parse(r.result));toast('JSON 导入成功')}catch(err){toast(`导入失败：${err.message}`,'error')}};r.readAsText(f);e.target.value=''};
    $('#refreshJsonBtn').onclick=refreshJson;$('#applyJsonBtn').onclick=()=>{try{importProject(JSON.parse(el.jsonText.value));toast('JSON 已应用')}catch(err){toast(`JSON 错误：${err.message}`,'error')}};$('#copyJsonBtn').onclick=async()=>{refreshJson();await navigator.clipboard.writeText(el.jsonText.value);toast('JSON 已复制')};
    $('#saveLocalBtn').onclick=()=>{localStorage.setItem('yishi-layout-editor',JSON.stringify(project));markDirty(false);toast('已保存到浏览器')};$('#loadLocalBtn').onclick=()=>{const x=localStorage.getItem('yishi-layout-editor');if(!x){toast('没有浏览器存档','warn');return}importProject(JSON.parse(x));toast('已读取浏览器存档')};
    $('#newProjectBtn').onclick=()=>showModal('新建项目','<p>新建会替换当前画布，未导出的修改将丢失。</p>',()=>{project=defaultProject();currentScreenId='s1';selectedId='__background';history=[];future=[];renderAll();fitStage();markDirty()});
    $('#undoBtn').onclick=()=>{if(!history.length)return;future.push(JSON.stringify(project));restore(history.pop())};$('#redoBtn').onclick=()=>{if(!future.length)return;history.push(JSON.stringify(project));restore(future.pop())};
    $$('.right-tab').forEach(tab=>tab.onclick=()=>{$$('.right-tab').forEach(x=>x.classList.toggle('active',x===tab));const mode=tab.dataset.tab;el.inspector.style.display=mode==='inspector'?'block':'none';el.jsonPanel.classList.toggle('active',mode==='json');el.dialoguePanel.classList.toggle('active',mode==='dialogue');if(mode==='json')refreshJson();if(mode==='dialogue')renderDialogues()});$('#dialogueSearch').oninput=renderDialogues;$('#addDialogueBtn').onclick=()=>{mutate(()=>project.dialogues.push(normalizeDialogue({dialogue_id:'new_dialogue',line_no:(project.dialogues.length||0)+1,speaker:'',text:''})));renderDialogues()};
    $('#modalCancel').onclick=hideModal;$('#modalMask').onclick=e=>{if(e.target===e.currentTarget)hideModal()};
    el.stage.addEventListener('pointerdown',e=>{if(e.target===el.stage||e.target===el.stageBg||e.target===el.stageGrid){selectedId=null;renderAll()}});
    el.stage.addEventListener('pointermove',e=>{const r=el.stage.getBoundingClientRect();el.cursor.textContent=`X ${round((e.clientX-r.left)/r.width,3)} · Y ${round((e.clientY-r.top)/r.height,3)}`});
    window.addEventListener('keydown',e=>{if(['INPUT','TEXTAREA','SELECT'].includes(document.activeElement.tagName))return;if(e.key==='Delete')deleteSelected();if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='d'){e.preventDefault();duplicateSelected()}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='z'){e.preventDefault();$('#undoBtn').click()}if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='y'){e.preventDefault();$('#redoBtn').click()}const ent=selected();if(ent&&['ArrowLeft','ArrowRight','ArrowUp','ArrowDown'].includes(e.key)){e.preventDefault();snapshot();const sx=project.design.grid/project.design.width,sy=project.design.grid/project.design.height,step=e.shiftKey?10:1;if(e.key==='ArrowLeft')ent.x=clamp(ent.x-sx*step,0,1-ent.w);if(e.key==='ArrowRight')ent.x=clamp(ent.x+sx*step,0,1-ent.w);if(e.key==='ArrowUp')ent.y=clamp(ent.y-sy*step,0,1-ent.h);if(e.key==='ArrowDown')ent.y=clamp(ent.y+sy*step,0,1-ent.h);markDirty();renderAll()}});
    window.addEventListener('beforeunload',e=>{if(dirty){e.preventDefault();e.returnValue=''}});window.addEventListener('resize',()=>setTimeout(fitStage,60));
  }

  buildPresetOptions();bindEvents();selectedId='__background';renderAll();setTimeout(fitStage,50);
})();
