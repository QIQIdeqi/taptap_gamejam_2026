// csv_to_lua.js
// 把 assets/data/dialogues.csv / clues.csv 编译为 scripts/data_dialogues.lua / scripts/data_clues.lua
// 原因：Maker 运行时不会打包 assets/data/*.csv（非脚本、非标准资源类型），直接读 CSV 会失败，
//       游戏将回退到 GameData 内嵌兜底数据，导致策划在 CSV 中的编辑不生效。
//       脚本(scripts/*.lua)一定被 Maker 打包，因此把 CSV 生成 Lua 模块来保证运行时生效。
// 用法（在项目根目录执行）：node tools/csv_to_lua.js
// 之后重建游戏即可。编辑 CSV 后请重新运行本脚本。

const fs = require('fs');

function parseCSV(text) {
  if (text.charCodeAt(0) === 0xFEFF) text = text.slice(1); // 去 BOM
  const rows = [];
  let row = [], field = '', inQ = false;
  let i = 0, n = text.length;
  while (i < n) {
    const c = text[i];
    if (inQ) {
      if (c === '"') {
        if (text[i + 1] === '"') { field += '"'; i += 2; }
        else { inQ = false; i++; }
      } else { field += c; i++; }
    } else {
      if (c === '"') { inQ = true; i++; }
      else if (c === ',') { row.push(field); field = ''; i++; }
      else if (c === '\r') { i++; }
      else if (c === '\n') { row.push(field); rows.push(row); row = []; field = ''; i++; }
      else { field += c; i++; }
    }
  }
  if (field.length > 0 || row.length > 0) { row.push(field); rows.push(row); }
  return rows;
}

function trim(s) { return (s || '').replace(/^\s*(.*?)\s*$/, '$1'); }

// 用 Lua 长字符串 [==[ ... ]==] 包裹，自动提升定界符级别以避免与内容中的 ]==] 冲突
function luaStr(s) {
  s = s || '';
  let level = 2;
  while (s.indexOf(']' + '='.repeat(level) + ']') !== -1) level++;
  const mark = '='.repeat(level);
  return '[' + mark + '[' + s + ']' + mark + ']';
}

// ---------- dialogues ----------
const dlgRows = parseCSV(fs.readFileSync('assets/data/dialogues.csv', 'utf-8'));
const dlgHeader = dlgRows[0];
const dlgCol = {};
dlgHeader.forEach((h, idx) => dlgCol[trim(h)] = idx);
const dialogues = {}, temp = {};
for (let r = 1; r < dlgRows.length; r++) {
  const row = dlgRows[r];
  const did = trim(row[dlgCol['dialogue_id']]);
  if (!did) continue;
  dialogues[did] = dialogues[did] || { id: did, background: '', lines: [] };
  temp[did] = temp[did] || {};
  const ln = parseInt(row[dlgCol['line_no']], 10) || (Object.keys(temp[did]).length + 1);
  const bg = row[dlgCol['background']] || '';
  if (!dialogues[did].background && bg) dialogues[did].background = bg;
  temp[did][ln] = {
    speaker: row[dlgCol['speaker']] || '',
    portrait: row[dlgCol['portrait']] || '',
    clue: row[dlgCol['clue']] || '',
    portraitPosition: row[dlgCol['portrait_position']] || '1',
    text: row[dlgCol['text']] || '',
    background: bg,
  };
}
for (const did in temp) {
  const keys = Object.keys(temp[did]).map(Number).sort((a, b) => a - b);
  dialogues[did].lines = keys.map(k => temp[did][k]);
}

let out = '-- AUTO-GENERATED from assets/data/dialogues.csv — DO NOT EDIT BY HAND\n';
out += '-- Regenerate with: node tools/csv_to_lua.js\n\n';
out += 'local M = {}\n';
for (const did in dialogues) {
  const d = dialogues[did];
  out += 'M[' + JSON.stringify(did) + '] = {\n';
  out += '  id = ' + JSON.stringify(d.id) + ',\n';
  out += '  background = ' + luaStr(d.background) + ',\n';
  out += '  lines = {\n';
  for (const line of d.lines) {
    out += '    { speaker = ' + luaStr(line.speaker) +
           ', portrait = ' + luaStr(line.portrait) +
           ', portraitPosition = ' + luaStr(line.portraitPosition) +
           ', clue = ' + luaStr(line.clue);
    // 仅当该行背景与组默认背景不同时才写入 —— 表示该行「切镜头」
    if (line.background && line.background !== d.background) {
      out += ', background = ' + luaStr(line.background);
    }
    out += ', text = ' + luaStr(line.text) + ' },\n';
  }
  out += '  },\n};\n';
}
out += 'return M\n';
fs.writeFileSync('scripts/data_dialogues.lua', out, 'utf-8');

// ---------- clues ----------
const clueRows = parseCSV(fs.readFileSync('assets/data/clues.csv', 'utf-8'));
const clueHeader = clueRows[0];
const clueCol = {};
clueHeader.forEach((h, idx) => clueCol[trim(h)] = idx);
const clues = {};
for (let r = 1; r < clueRows.length; r++) {
  const row = clueRows[r];
  const id = trim(row[clueCol['id']]);
  if (!id) continue;
  clues[id] = {
    id: id,
    name: row[clueCol['name']] || '',
    category: row[clueCol['category']] || '',
    chapter: row[clueCol['chapter']] || '',
    description: row[clueCol['description']] || '',
    detail: row[clueCol['detail']] || '',
    image: row[clueCol['image']] || '',
  };
}
let out2 = '-- AUTO-GENERATED from assets/data/clues.csv — DO NOT EDIT BY HAND\n';
out2 += '-- Regenerate with: node tools/csv_to_lua.js\n\n';
out2 += 'local M = {}\n';
for (const id in clues) {
  const c = clues[id];
  out2 += 'M[' + JSON.stringify(id) + '] = {\n';
  out2 += '  id = ' + JSON.stringify(c.id) + ',\n';
  out2 += '  name = ' + luaStr(c.name) + ',\n';
  out2 += '  category = ' + luaStr(c.category) + ',\n';
  out2 += '  chapter = ' + luaStr(c.chapter) + ',\n';
  out2 += '  description = ' + luaStr(c.description) + ',\n';
  out2 += '  detail = ' + luaStr(c.detail) + ',\n';
  out2 += '  image = ' + luaStr(c.image) + ',\n';
  out2 += '};\n';
}
out2 += 'return M\n';
fs.writeFileSync('scripts/data_clues.lua', out2, 'utf-8');

console.log('Generated scripts/data_dialogues.lua (' + Object.keys(dialogues).length +
            ' dialogues) and scripts/data_clues.lua (' + Object.keys(clues).length + ' clues)');
